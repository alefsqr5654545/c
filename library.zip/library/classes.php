<?php
// TkFreamwork - Dedicated Freamwork Client Applications \\
###########################################################
###########################################################
###########################################################
#####              Freamwork Destraction              #####
#####-------------------------------------------------#####
#####                   TkFreamWork                   #####
#####             WebSite : www.tkstar.ir             #####
#####           PhoneNumber : +989017735378           #####
#####         Code and Idea by AmirAli Esteki         #####
#####  TkFreamWork   For TkStar Clients   Dedicateds  #####
#####          Freamwork Version : 0.0.00001          #####
#####      Concessionaire Freamwork : TkStar Co.      #####
#####      Lunar Constructions Date : 1438/06/02      #####
#####     Helical Constructions Date : 1395/12/11     #####
#####    Gregorian Constructions Date : 2017/03/01    #####
#####-------------------------------------------------#####
#####                End Destraction .                #####
###########################################################
###########################################################
###########################################################
if(is_file(scriptdir.ds."library".ds."classes".ds."jdate.php")&&file_exists(scriptdir.ds."library".ds."classes".ds."jdate.php")):require_once(scriptdir.ds."library".ds."classes".ds."jdate.php");endif;
?>